import { Component, OnInit } from '@angular/core';
import { FirebaseServiceService } from '../services/firebase-service.service';

@Component({
  selector: 'app-travels',
  templateUrl: './travels.page.html',
  styleUrls: ['./travels.page.scss'],
})
export class TravelsPage implements OnInit {

  constructor(private firebaseServiceService:FirebaseServiceService) {}

  config: any;
  collection = { count: 0, data: [] }

  ngOnInit() {

    this.firebaseServiceService.getTravel().subscribe(resp=>{
      this.collection.data = resp.map((e:any)=>{
        return{
         id:e.payload.doc.data().id,
         carPlate:e.payload.doc.data().carPlate,
         driver:e.payload.doc.data().driver,
         startingPoint:e.payload.doc.data().startingPoint,
         departureTime:e.payload.doc.data().departureTime,
         finalPoint:e.payload.doc.data().finalPoint,
         checkIn:e.payload.doc.data().checkIn,
         pay:e.payload.doc.data().pay
        }
      })
    },error=>{
      console.error(error);
    });
  }

  

}
