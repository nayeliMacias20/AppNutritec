export const environment = {
  production: false,
  mapboxKey: 'pk.eyJ1Ijoibm9zZmVyYSIsImEiOiJja3JqeXBqNWgwYmpqMnlvOWVtZTNhZnNxIn0.UD0uxU2pEmcUxJpIF6eJPg',
   firebase: {
    apiKey: "AIzaSyB5JFU8fkD3hwUQHaaK6GxS3GWSDy41PLE",
    authDomain: "control-de-taxis-df133.firebaseapp.com",
    projectId: "control-de-taxis-df133",
    storageBucket: "control-de-taxis-df133.appspot.com",
    messagingSenderId: "1001417808567",
    appId: "1:1001417808567:web:81336f74d1007880f48b32",
    measurementId: "G-4ZCPS65NPF"
  }
};
