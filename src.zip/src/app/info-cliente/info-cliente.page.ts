import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-info-cliente',
  templateUrl: './info-cliente.page.html',
  styleUrls: ['./info-cliente.page.scss'],
})
export class InfoClientePage implements OnInit {

  constructor(public router:Router) { }

  ngOnInit() {
  }
  Code(){
    this.router.navigate(['/home'])
  }
}
