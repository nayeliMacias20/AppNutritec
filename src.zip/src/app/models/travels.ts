export interface travelsI{
    id?:string;
    carPlate:string;
    driver:string;
    startingPoint:string;
    departureTime:Date;
    finalPoint:string;
    checkIn:Date;
    pay:number;
}