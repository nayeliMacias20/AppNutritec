import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-tarjeta',
  templateUrl: './tarjeta.page.html',
  styleUrls: ['./tarjeta.page.scss'],
})
export class TarjetaPage implements OnInit {

  constructor(public router:Router,
    public alertController: AlertController) { }

  ngOnInit() {
  }
  agregarTarjeta(){
    this.router.navigate(['/payment'])
  }
  async alertacvv(){
      const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'CVV',
      message: 'El CVV es un número de 3 dígitos que está al reverso de tu tarjeta.',
      buttons: ['Entendido']
     });

      await alert.present();
  }
  async alerta(){
    const alert = await this.alertController.create({
    cssClass: 'my-custom-class',
    header: 'Fecha de vencimiento',
    message: 'La fecha de vencimiento se ubica en la parte frontal inferior de tu tarjeta.',
    buttons: ['Entendido']
   });

    await alert.present();
}
}
